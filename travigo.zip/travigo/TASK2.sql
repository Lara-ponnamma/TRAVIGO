#2.
#a. How many female passengers traveled a minimum distance of 600KMs?

select count(*) from passenger where gender = 'F' and distance >= 600;

#b. Write a query to display the passenger details whose travel distance is greater than 500 and who are traveling in a sleeper bus

select * from passenger where distance > 500 and bus_type = 'sleeper';

#c.Select passenger names whose names start with the character'S'

select passenger_name from passenger where passenger_name like 'S%';

#d.Calculate the price charged for each passenger,displaying the Passenger name,Boarding City,Destination City,Bustype,andPrice in the output

select p.passenger_name,p.boarding_city,p.destination_city,p.bus_type,pr.price from passenger p , price pr where p.passenger_id = pr.id;

#e.What are the passenger name(s)and the ticket price for those who traveled 1000KMs Sitting in a bus

select p.passenger_name,pr.price from passenger p, price pr  where p.distance = 1000 and p.bus_type = 'sitting';


#f.What will be the Sitting and Sleeper bus charge for Pallavi to travel from Bangalore to Panaji?

select p.passenger_name,pr.bus_type,pr.price 
from passenger p, price pr
where p.passenger_name like 'pallavi' and p.distance=pr.distance;

#g.Alter the column category with the value "Non-AC" where the Bus_Type is sleeper

update passenger
set Category = 'Non-AC' where Bus_Type = 'Sleeper';

select * from passenger;

#h. Delete an entry from the table where the passenger name is Piyush and commit this change in the database.

delete  from passenger where passenger_name = 'piyush';
commit;

#i.Truncate the table passenger and comment on the number of rows in the table( explainifrequired).

truncate table passenger;

#There are no rows present as we have truncated the table passenger only the structure of table is present.alter

#j. Delete the table passenger from the database

drop table passenger;
