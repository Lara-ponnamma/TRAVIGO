# 1.)Creating the schemaand required tablesusing MySQ Lworkbencha
#a). CreateaschemanamedTravegoandcreatethetablesmentionedabovewiththementionedcolumnnames.Also,declaretherelevantdatatypesforeachfeature/columninthedataset
drop database travigo;
create database travigo;

use travigo;

create table passenger(
passenger_id int primary key,
passenger_name varchar(20),
category varchar(20),
gender varchar(20),
boarding_city varchar(20),
destination_city varchar(20),
distance int,
bus_type varchar(20) );

create table price(
id int primary key, 
bus_type varchar(20),
distance int,
price int);

#b.)Insert the data in the newly created tables.

insert into passenger values
(1,'SEJAL','AC','F','BENGALURU','CHENNAI',350,'SLEEPER'),
(2,'ANMOL','NON-AC','M','MUMBAI','HYDERABAD',700,'SITTING'),
(3,'PALLAVI','AC','F','PANAJI','BENGALURU',600,'SLEEPER'),
(4,'KUSHBOO','AC','F','CHENNAI','MUMBAI',1500,'SLEEPER'),
(5,'UDIT','NON-AC','M','TRIVANDRUM','PANAJI',1000,'SLEEPER'),
(6,'ANKUR','AC','M','NAGPUR','HYDERABAD',500,'SITTING'),
(7,'HEMANT','NON-AC','M','PANAJI','MUMBAI',700,'SLEEPER'),
(8,'MANISH','NON-AC','M','HYDERABAD','BENGALURU',500,'SITTING'),
(9,'PIYUSH','AC','M','PUNE','NAGPUR',700,'SITTING');

insert into price values
(1,'SLEEPER',350,770),
(2,'SLEEPER',500,1100),
(3,'SLEEPER',600,1320),
(4,'SLEEPER',700,1540),
(5,'SLEEPER',1000,2200),
(6,'SLEEPER',1200,2640),
(7,'SLEEPER',1500,2700),
(8,'SITTING',500,620),
(9,'SITTING',600,744),
(10,'SITTING',700,868),
(11,'SITTING',1000,1240),
(12,'SITTING',1200,1488),
(13,'SITTING',1500,1860);

